create procedure addTest(IN `_fNo` varchar(30))
  BEGIN

declare _fId int;
select id into _fId from film where fNo=_fNo;


END;

