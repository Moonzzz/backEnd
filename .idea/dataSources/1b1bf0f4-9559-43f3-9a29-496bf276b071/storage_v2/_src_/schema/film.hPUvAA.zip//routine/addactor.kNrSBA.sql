create procedure addActor(IN `_fNo` varchar(30), IN `_name` varchar(2000), IN `_url` varchar(2000), IN `_len` int)
  BEGIN

declare _aId int;
declare i int DEFAULT 0;
DECLARE isExist int DEFAULT 0;
DECLARE _aName varchar(100);
DECLARE _aUrl VARCHAR (100);
declare _fId int DEFAULT 0;


DECLARE CONTINUE HANDLER FOR SQLSTATE '23000'
SET isExist = 1;
-- 必须要有set 而且下面不能是声明变量
lp1 :
LOOP
if(_fId=0) THEN
select id into _fId from film where fNo=_fNo;
end if;
IF (i > _len) THEN
	LEAVE lp1;


END
IF;


SET _aName = SUBSTRING_INDEX(
	SUBSTRING_INDEX(_name, ',', i),
	',' ,- 1
);


SET _aUrl = SUBSTRING_INDEX(
	SUBSTRING_INDEX(_url, ',', i),
	',' ,- 1
);

INSERT INTO actor
VALUES
	(NULL, _aName, _aUrl);


IF (isExist < 1) THEN
	SELECT
		id INTO _aId
	FROM
		actor
	WHERE
		NAME = _aName
	AND url = _aUrl;

INSERT INTO filmandactor
VALUES
	(NULL, _fId, _aId);


SET isExist = 0;


END
IF;


SET i = i + 1;


END
LOOP
;


END;

